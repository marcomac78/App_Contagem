package com.example.aplicativodecontagem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AlertDialogLayout;

import android.content.Intent;
import android.os.Bundle;
import android.service.autofill.OnClickAction;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button semdano, dano1, dano2, dano3, dano4, resetar, run;
    private EditText editcontador;

    private int contadorZero = 0;
    private int contadorUm = 0;
    private int contadorDois = 0;
    private int contadorTres = 0;
    private int contadorQuatro = 0;

    private int contadorGeral = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editcontador = (EditText) findViewById(R.id.editContador);

        semdano = (Button) findViewById(R.id.semdanobutton);
        dano1 = (Button) findViewById(R.id.dano1button);
        dano2 = (Button) findViewById(R.id.dano2button);
        dano3 = (Button) findViewById(R.id.dano3button);
        dano4 = (Button) findViewById(R.id.dano4button);
        resetar = (Button) findViewById(R.id.resetarbutton);
        run = (Button) findViewById(R.id.runbutton);

        semdano.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contadorZero++;
                contadorGeral++;

                editcontador.setText("Contador: " + contadorGeral);

                if (contadorGeral == 100) {
                    Toast toast = Toast.makeText(MainActivity.this, "Você já contou 100 cometas!", Toast.LENGTH_LONG);
                    toast.show();
                }
            }

        });

        dano1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contadorUm++;
                contadorGeral++;

                editcontador.setText("Contador: " + contadorGeral);

                if (contadorGeral == 100) {
                    // Toast.makeText("");
                }
            }

        });
        dano2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contadorDois++;
                contadorGeral++;

                editcontador.setText("Contador: " + contadorGeral);

                if (contadorGeral == 100) {
                    // Toast.makeText("");
                }
            }

        });

        dano3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contadorTres++;
                contadorGeral++;

                editcontador.setText("Contador: " + contadorGeral);

                if (contadorGeral == 100) {
                    // Toast.makeText("");
                }
            }

        });

        dano4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contadorQuatro++;
                contadorGeral++;

                editcontador.setText("Contador: " + contadorGeral);

                if (contadorGeral == 100) {
                    // Toast.makeText("");
                }
            }

        });

        resetar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                contadorGeral--;

                editcontador.setText("Contador: " + contadorGeral);
            }

        });

        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        Bundle bundle = new Bundle();
        bundle.putInt("contadorZero", contadorZero);
        bundle.putInt("contadorUm", contadorUm);
        bundle.putInt("contadorDois", contadorDois);
        bundle.putInt("contadorTres", contadorTres);
        bundle.putInt("contadorQuatro", contadorQuatro);
        intent.putExtras(bundle);

        run.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                botaoCallActivity();
                startActivity(intent);
            }
            });
    }
    public void botaoCallActivity() {
        startActivity(new Intent(MainActivity.this,MainActivity2.class));

    }

}

