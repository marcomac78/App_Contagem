package com.example.aplicativodecontagem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.BreakIterator;

public class MainActivity2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            int contadorZero = bundle.getInt("");
            int contadorUm = bundle.getInt("");
            int contadorDois = bundle.getInt("");
            int contadorTres = bundle.getInt("");
            int contadorQuatro = bundle.getInt("");
        }
        TextView contadorZero = findViewById(R.id.myTextViewNumeroD0);
        TextView contadorUm = findViewById(R.id.myTextViewNumeroD1);
        TextView contadorDois = findViewById(R.id.myTextViewNumeroD2);
        TextView contadorTres = findViewById(R.id.myTextViewNumeroD3);
        TextView contadorQuatro = findViewById(R.id.myTextViewNumeroD4);




    }


        }
